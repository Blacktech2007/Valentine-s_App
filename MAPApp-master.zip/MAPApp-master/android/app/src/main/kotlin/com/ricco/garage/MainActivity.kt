package com.ricco.garage

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
